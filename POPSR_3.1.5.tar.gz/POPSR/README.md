# *POPSR*
The *POPSR* package provides the complex processing routine 'compscomp.R',
plotting functions and a Shiny interface to POPSC,
which is a C program that needs to be compiled separately;
the latter should be present under 'POPScomp/POPSR/bin/pops' as a link.
See the  [Wiki](https://github.com/Fraternalilab/POPScomp/wiki) for more information.
